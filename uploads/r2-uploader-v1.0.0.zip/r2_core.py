#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R2Uploader 核心逻辑：WebP 压缩 + AWS SigV4 签名 + 上传 R2（无 GUI 依赖）。"""
import hashlib
import hmac
import io
import json
import os
import sys
import urllib.parse
import http.client
from datetime import datetime, timezone

try:
    from PIL import Image
except ImportError:
    Image = None

VERSION = "1.0.0"


# ---------------------------------------------------------------- 路径与配置
def app_dir():
    if getattr(sys, "frozen", False):  # PyInstaller 打包后
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def config_path():
    return os.path.join(app_dir(), "config.json")


def default_config():
    return {
        "accountId": "",
        "accessKeyId": "",
        "secretAccessKey": "",
        "bucket": "",
        "publicBaseUrl": "",
        "endpoint": "",
        "region": "auto",
        "keyPrefix": "images",
        "dateSubfolder": True,
        "webpConvert": True,
        "webpQuality": 80,
        "maxWidth": 0,
        "concurrency": 3,
    }


def load_config(path=None):
    try:
        with open(path or config_path(), encoding="utf-8") as f:
            cfg = json.load(f)
        d = default_config()
        d.update({k: v for k, v in cfg.items() if k in d})
        return d
    except Exception:
        return default_config()


def save_config(cfg, path=None):
    with open(path or config_path(), "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------- AWS SigV4
def aws_uri_encode(s):
    """AWS 风格路径编码：保留 A-Za-z0-9-._~ 与 /，其余字节 %XX（大写）。"""
    out = []
    for ch in s:
        o = ord(ch)
        if (0x41 <= o <= 0x5A or 0x61 <= o <= 0x7A or 0x30 <= o <= 0x39
                or ch in "-._~/"):
            out.append(ch)
        else:
            out.append("%" + ("%02X" % o))
    return "".join(out)


def sign_v4(secret, datestamp, region, service, method, canonical_uri,
            canonical_query, signed_headers, canonical_headers, payload_hash,
            amz_date):
    scope = f"{datestamp}/{region}/{service}/aws4_request"
    canonical_request = "\n".join([
        method, canonical_uri, canonical_query,
        canonical_headers, signed_headers, payload_hash,
    ])
    string_to_sign = "\n".join([
        "AWS4-HMAC-SHA256", amz_date, scope,
        hashlib.sha256(canonical_request.encode()).hexdigest(),
    ])

    def hmac_sha(key, msg):
        return hmac.new(key, msg.encode(), hashlib.sha256).digest()

    k_date = hmac_sha(("AWS4" + secret).encode(), datestamp)
    k_region = hmac_sha(k_date, region)
    k_service = hmac_sha(k_region, service)
    k_signing = hmac_sha(k_service, "aws4_request")
    signature = hmac.new(k_signing, string_to_sign.encode(),
                         hashlib.sha256).hexdigest()
    return signature


def upload_to_r2(cfg, key, body_bytes, content_type="image/webp", timeout=120,
                 region=None):
    """PutObject 上传到 R2。返回 (public_url, key)。异常由调用方处理。"""
    account_id = cfg["accountId"].strip()
    endpoint = (cfg.get("endpoint") or "").strip().rstrip("/") or \
        f"https://{account_id}.r2.cloudflarestorage.com"
    bucket = cfg["bucket"].strip()
    if not bucket:
        raise ValueError("Bucket 未填写")
    region = region or cfg.get("region") or "auto"

    parsed = urllib.parse.urlparse(endpoint)
    host = parsed.netloc
    scheme = parsed.scheme or "https"

    payload_hash = hashlib.sha256(body_bytes).hexdigest()
    now = datetime.now(timezone.utc)
    amz_date = now.strftime("%Y%m%dT%H%M%SZ")
    datestamp = now.strftime("%Y%m%d")

    canonical_uri = "/" + bucket + "/" + aws_uri_encode(key)
    canonical_query = ""
    canonical_headers = (
        f"host:{host}\n"
        f"x-amz-content-sha256:{payload_hash}\n"
        f"x-amz-date:{amz_date}\n"
    )
    signed_headers = "host;x-amz-content-sha256;x-amz-date"

    signature = sign_v4(
        cfg["secretAccessKey"], datestamp, region, "s3",
        "PUT", canonical_uri, canonical_query, signed_headers,
        canonical_headers, payload_hash, amz_date,
    )
    auth = (
        f"AWS4-HMAC-SHA256 "
        f"Credential={cfg['accessKeyId'].strip()}/{datestamp}/{region}/s3/aws4_request, "
        f"SignedHeaders={signed_headers}, Signature={signature}"
    )

    conn = http.client.HTTPSConnection(host, timeout=timeout)
    try:
        conn.putrequest("PUT", canonical_uri)
        conn.putheader("Host", host)
        conn.putheader("x-amz-content-sha256", payload_hash)
        conn.putheader("x-amz-date", amz_date)
        conn.putheader("Content-Type", content_type)
        conn.putheader("Authorization", auth)
        conn.putheader("Content-Length", str(len(body_bytes)))
        conn.endheaders(body_bytes)
        resp = conn.getresponse()
        resp_body = resp.read()
        if resp.status not in (200, 201, 204):
            raise RuntimeError(
                f"上传失败 HTTP {resp.status}: "
                f"{resp_body[:300].decode('utf-8', 'ignore')}")
    finally:
        conn.close()

    base = (cfg.get("publicBaseUrl") or "").strip().rstrip("/")
    if not base:
        return "", key  # 未配置外链域名时仍已上传成功
    if not urllib.parse.urlparse(base).scheme:
        base = "https://" + base
    return f"{base}/{key}", key


# ---------------------------------------------------------------- WebP 压缩
def to_webp_bytes(src_path, quality=80, max_width=0):
    if Image is None:
        raise RuntimeError("未安装 Pillow，无法转 WebP（pip install pillow）")
    img = Image.open(src_path)
    img = img.convert("RGBA" if img.mode in ("RGBA", "LA", "P") else "RGB")
    if max_width and img.width > max_width:
        h = round(img.height * max_width / img.width)
        img = img.resize((max_width, h), Image.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, "WEBP", quality=quality, method=6)
    return buf.getvalue()


# ---------------------------------------------------------------- Key 生成
def build_key(cfg, src_name, ext=".webp"):
    prefix = (cfg.get("keyPrefix") or "images").strip().strip("/")
    prefix = prefix + "/" if prefix else ""
    date_part = ""
    if cfg.get("dateSubfolder"):
        now = datetime.now()
        date_part = f"{now.year}/{now.month:02d}/{now.day:02d}/"
    base = os.path.splitext(os.path.basename(src_name))[0]
    safe = "".join(c if (c.isalnum() or c in "-._~" or ord(c) > 127) else "-"
                   for c in base)
    safe = safe.strip(".").strip("-") or "image"
    return prefix + date_part + safe + ext