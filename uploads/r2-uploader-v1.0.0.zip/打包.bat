@echo off
chcp 65001 >nul
title R2Uploader 打包工具
cd /d "%~dp0"

echo [1/3] 安装依赖（pillow + pyinstaller）...
python -m pip install -r requirements.txt

if errorlevel 1 (
    echo 依赖安装失败，请确认已安装 Python 3.8+ 并加入 PATH
    pause
    exit /b 1
)

echo [2/3] 打包为单文件 exe...
pyinstaller --onefile --windowed --name R2Uploader --clean --noconfirm r2_uploader.py

if errorlevel 1 (
    echo 打包失败，请查看上方报错
    pause
    exit /b 1
)

echo [3/3] 完成！
echo exe 位于 dist\R2Uploader.exe，可直接分发使用。
echo 配置（config.json）会保存在 exe 同目录。
pause