# R2Uploader —— 独立版 Cloudflare R2 图片上传工具（Windows）

上传图片 → 转 WebP 压缩 → 直传 Cloudflare R2 → 一键复制公开链接。

- **完全独立**：不依赖原 Actor CMS 的 `cloudflare-r2` 插件，不读写原项目的任何文件，可单独使用、分发
- **纯标准库 GUI**（Tkinter）+ Pillow，Windows 原生界面
- 手写 AWS SigV4 签名（S3 兼容 API），无 SDK 依赖

---

## 一、运行方式（两种任选）

### 方式 A：直接运行源码（需要 Python 3.8+）
```bat
pip install -r requirements.txt
python r2_uploader.py
```

### 方式 B：打包成独立 exe（发给别人用，无需装 Python）
双击运行 **`打包.bat`**，完成后 exe 在 `dist\R2Uploader.exe`。
- 首次运行打包会弹一闪而过的命令行窗口属正常
- exe 与 `config.json` 同目录存放，绿色免安装

---

## 二、界面使用

1. **填 R2 配置**（与 Cloudflare R2 后台一致）：
   - `Account ID`：Cloudflare 控制台 → R2 → 右侧 API 区域
   - `Access Key ID` / `Secret Access Key`：R2 → 管理 R2 API 令牌（需「对象读/写」权限）
   - `Bucket`：桶名（如 `photo`）
   - `Public Base URL`：公开访问域名（如 `img.sglxq.cn`，可留空则只上传不生成链接）
   - `Endpoint`（可选）：自定义 S3 endpoint，留空自动用 `https://{AccountId}.r2.cloudflarestorage.com`
   - `Key 前缀`：对象 key 前缀（如 `images/mqq`，留空则桶根）
2. 点 **保存配置**（存到程序目录 `config.json`，下次打开自动加载）
3. **添加图片…**（支持多选 jpg/png/webp/gif/bmp）
4. 勾选 **转 WebP 压缩**，调 **质量**（1-100，常用 75-85，质量与体积平衡）
   - 可选 **最大宽度** 限制（如 1920，0 = 不缩放）
5. **开始上传** → 日志区逐个显示 `OK 文件名 -> https://img.xxx/...`
6. 上传完可 **复制全部链接** 或 **保存链接到 txt**

---

## 三、与「Cloudflare R2 图片上传」插件的关系

| | 原插件 | 本工具 |
|---|---|---|
| 运行环境 | Actor CMS 后台（Node） | Windows 桌面（Python 独立程序） |
| 依赖 | 原项目 `@aws-sdk/client-s3` 等 | 仅 Pillow |
| 写原项目配置 | 是（`config.json` plugins.data） | **否，完全不接触** |
| 用途 | 后台批量传图 | 便携上传、转 WebP、取链接 |

两者可同时使用、互不影响；上传对象都在同一个 R2 桶里。

---

## 四、说明与注意

- **同名同路径会覆盖** R2 中已有对象（默认按日期建目录可减少冲突；不开日期目录时请留意）
- Secret Access Key 以明文保存在程序目录 `config.json`——**请勿把该文件或 exe 目录分享出去**
- 网络超时默认 120 秒/张；并发默认 3（可在界面改 1-10）
- webp 质量/宽度/并发改动即时生效，无需重启