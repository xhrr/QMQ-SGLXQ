#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
R2 Uploader —— 独立版 Cloudflare R2 图片上传小工具（Windows 桌面）
==============================================================
功能：选择图片 -> 转 WebP 压缩 -> 上传到 Cloudflare R2（S3 兼容 API），
      自动生成公开外链并可一键复制。
- GUI：Tkinter（Python 自带）；WebP：Pillow；签名：手写 AWS SigV4（r2_core）
- 不依赖原 Actor CMS 插件，不读写原项目的任何文件
"""
import os
import queue
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from r2_core import (VERSION, default_config, load_config, save_config,
                     to_webp_bytes, upload_to_r2, build_key)

APP_NAME = "R2Uploader"


class App:
    def __init__(self, root):
        self.root = root
        self.cfg = load_config()
        self.files = []          # [(src_path, display_name)]
        self.results = []        # [{"file": ..., "url": ...}]
        self.uploading = False
        self.queue = queue.Queue()
        root.title(f"{APP_NAME} v{VERSION} —— Cloudflare R2 图片上传")
        root.geometry("780x660")
        root.minsize(680, 560)
        self._build_ui()
        self._load_ui_config()

    # ---------------- UI ----------------
    def _build_ui(self):
        pad = {"padx": 8, "pady": 4}

        box = ttk.LabelFrame(self.root, text=" R2 配置 ")
        box.pack(fill="x", **pad)
        grid = ttk.Frame(box)
        grid.pack(fill="x", padx=8, pady=6)
        self.vars = {}
        fields = [
            ("accountId", "Account ID"),
            ("accessKeyId", "Access Key ID"),
            ("secretAccessKey", "Secret Access Key"),
            ("bucket", "Bucket"),
            ("publicBaseUrl", "Public Base URL"),
            ("endpoint", "Endpoint（可选）"),
            ("keyPrefix", "Key 前缀"),
        ]
        for i, (key, label) in enumerate(fields):
            ttk.Label(grid, text=label).grid(row=i, column=0, sticky="w", pady=2)
            var = tk.StringVar()
            ent = ttk.Entry(grid, textvariable=var, show="" if key != "secretAccessKey" else "*",
                            width=54)
            ent.grid(row=i, column=1, sticky="we", pady=2, padx=(6, 0))
            self.vars[key] = var
        grid.columnconfigure(1, weight=1)

        opt = ttk.Frame(box)
        opt.pack(fill="x", padx=8, pady=(0, 6))
        self.vars["webpConvert"] = tk.BooleanVar(value=True)
        self.vars["dateSubfolder"] = tk.BooleanVar(value=True)
        self.vars["webpQuality"] = tk.IntVar(value=80)
        self.vars["maxWidth"] = tk.IntVar(value=0)
        self.vars["concurrency"] = tk.IntVar(value=3)
        ttk.Checkbutton(opt, text="转 WebP 压缩",
                        variable=self.vars["webpConvert"]).grid(row=0, column=0, sticky="w")
        ttk.Label(opt, text="质量").grid(row=0, column=1, sticky="e")
        ttk.Spinbox(opt, from_=1, to=100, width=4,
                    textvariable=self.vars["webpQuality"]).grid(row=0, column=2, padx=(2, 10))
        ttk.Label(opt, text="最大宽度").grid(row=0, column=3, sticky="e")
        ttk.Spinbox(opt, from_=0, to=99999, width=7,
                    textvariable=self.vars["maxWidth"]).grid(row=0, column=4, padx=(2, 10))
        ttk.Label(opt, text="并发").grid(row=0, column=5, sticky="e")
        ttk.Spinbox(opt, from_=1, to=10, width=4,
                    textvariable=self.vars["concurrency"]).grid(row=0, column=6)
        ttk.Checkbutton(opt, text="按日期建目录 YYYY/MM/DD",
                        variable=self.vars["dateSubfolder"]).grid(row=1, column=0, sticky="w", columnspan=7)
        ttk.Button(box, text="保存配置", command=self.save_cfg).pack(side="left", padx=8, pady=(0, 8))
        ttk.Label(box, text="配置保存在程序目录 config.json（含密钥，勿外传）").pack(
            side="left", padx=8, pady=(0, 8))

        fbox = ttk.LabelFrame(self.root, text=" 图片列表 ")
        fbox.pack(fill="both", expand=True, **pad)
        bar = ttk.Frame(fbox)
        bar.pack(fill="x", padx=8, pady=(6, 2))
        ttk.Button(bar, text="添加图片…", command=self.add_files).pack(side="left", padx=(0, 6))
        ttk.Button(bar, text="移除选中", command=self.remove_selected).pack(side="left", padx=(0, 6))
        ttk.Button(bar, text="清空列表", command=self.clear_files).pack(side="left", padx=(0, 6))
        self.copy_btn = ttk.Button(bar, text="复制全部链接", command=self.copy_urls, state="disabled")
        self.copy_btn.pack(side="left", padx=(0, 6))
        self.save_btn = ttk.Button(bar, text="保存链接到 txt", command=self.save_urls_txt,
                                   state="disabled")
        self.save_btn.pack(side="left")
        self.upload_btn = ttk.Button(bar, text="开始上传", command=self.start_upload)
        self.upload_btn.pack(side="right", padx=(6, 0))

        self.listbox = tk.Listbox(fbox, selectmode=tk.EXTENDED, height=8)
        self.listbox.pack(fill="both", expand=True, padx=8, pady=4)

        lbox = ttk.LabelFrame(self.root, text=" 日志 / 链接 ")
        lbox.pack(fill="both", expand=True, **pad)
        self.log = tk.Text(lbox, height=10, state="disabled", wrap="none")
        self.log.pack(fill="both", expand=True, padx=8, pady=(4, 8))
        self.log.tag_configure("ok", foreground="#1a7f37")
        self.log.tag_configure("err", foreground="#cf222e")

    def _load_ui_config(self):
        for k, var in self.vars.items():
            v = self.cfg.get(k)
            if v is None:
                continue
            if isinstance(var, tk.BooleanVar):
                var.set(bool(v))
            elif isinstance(var, tk.IntVar):
                var.set(int(v))
            else:
                var.set(str(v))

    def _collect_cfg(self):
        for k, var in self.vars.items():
            if isinstance(var, tk.BooleanVar):
                self.cfg[k] = bool(var.get())
            elif isinstance(var, tk.IntVar):
                self.cfg[k] = int(var.get())
            else:
                self.cfg[k] = var.get().strip()

    # ---------------- 交互 ----------------
    def save_cfg(self):
        self._collect_cfg()
        save_config(self.cfg)
        self._log("配置已保存到程序目录 config.json", "ok")

    def add_files(self):
        paths = filedialog.askopenfilenames(
            title="选择图片",
            filetypes=[("图片", "*.jpg *.jpeg *.png *.webp *.gif *.bmp"), ("所有文件", "*.*")])
        existing = {f[0] for f in self.files}
        for p in paths:
            if p not in existing:
                self.files.append((p, os.path.basename(p)))
        self._refresh_list()

    def remove_selected(self):
        for i in reversed(self.listbox.curselection()):
            self.files.pop(i)
        self._refresh_list()

    def clear_files(self):
        self.files.clear()
        self._refresh_list()

    def _refresh_list(self):
        self.listbox.delete(0, tk.END)
        for _, name in self.files:
            self.listbox.insert(tk.END, name)
        done = len(self.results) > 0
        self.copy_btn.config(state="normal" if done else "disabled")
        self.save_btn.config(state="normal" if done else "disabled")

    def _log(self, msg, tag=None):
        self.queue.put((msg, tag))

    def _append_log(self, msg, tag=None):
        self.log.config(state="normal")
        self.log.insert(tk.END, msg + "\n", tag or ())
        self.log.see(tk.END)
        self.log.config(state="disabled")

    # ---------------- 上传 ----------------
    def start_upload(self):
        if self.uploading:
            return
        if not self.files:
            messagebox.showwarning("提示", "请先添加图片")
            return
        self._collect_cfg()
        missing = [f for f in ("accountId", "accessKeyId", "secretAccessKey", "bucket")
                   if not self.cfg.get(f)]
        if missing:
            messagebox.showwarning("提示", "请填写 R2 配置：" + ", ".join(missing))
            return
        self.uploading = True
        self.upload_btn.config(state="disabled", text="上传中…")
        self.results = []
        self._log(f"开始上传 {len(self.files)} 张…")
        threading.Thread(target=self._worker, daemon=True).start()

    def _worker(self):
        files = list(self.files)
        concurrency = max(1, min(10, int(self.cfg["concurrency"])))
        idx = 0
        lock = threading.Lock()
        failed = []

        def do_one(src, name):
            try:
                if self.cfg["webpConvert"]:
                    body = to_webp_bytes(src, quality=int(self.cfg["webpQuality"]),
                                         max_width=int(self.cfg["maxWidth"]))
                else:
                    with open(src, "rb") as f:
                        body = f.read()
                key = build_key(self.cfg, name)
                url, _ = upload_to_r2(self.cfg, key, body)
                with lock:
                    self.results.append({"file": name, "url": url})
                self._log(f"OK  {name}  ->  {url or '(未配置外链域名)'}", "ok")
            except Exception as e:
                with lock:
                    failed.append((name, str(e)))
                self._log(f"FAIL {name}: {e}", "err")

        def worker():
            nonlocal idx
            while True:
                with lock:
                    if idx >= len(files):
                        return
                    src, name = files[idx]
                    idx += 1
                do_one(src, name)

        threads = [threading.Thread(target=worker, daemon=True)
                   for _ in range(concurrency)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        self.queue.put(("__done__", None))

    def _on_done(self):
        self.uploading = False
        self.upload_btn.config(state="normal", text="开始上传")
        self._refresh_list()
        self._append_log(
            f"完成：上传成功 {len(self.results)} 张"
            f"{'，失败 ' + str(len(self.files) - len(self.results)) + ' 张' if len(self.results) != len(self.files) else ''}",
            "ok" if self.results else "err")

    def copy_urls(self):
        if not self.results:
            return
        text = "\n".join(r["url"] for r in self.results if r["url"])
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self._append_log(f"已复制 {len([r for r in self.results if r['url']])} 条链接到剪贴板", "ok")

    def save_urls_txt(self):
        if not self.results:
            return
        path = filedialog.asksaveasfilename(
            title="保存链接", defaultextension=".txt",
            filetypes=[("文本", "*.txt")], initialfile="r2_links.txt")
        if not path:
            return
        with open(path, "w", encoding="utf-8") as f:
            for r in self.results:
                if r["url"]:
                    f.write(r["url"] + "\n")
        self._append_log("链接已保存到 " + path, "ok")


def main():
    root = tk.Tk()
    app = App(root)

    def poll():
        try:
            while True:
                msg, tag = app.queue.get_nowait()
                if msg == "__done__":
                    app._on_done()
                else:
                    app._append_log(msg, tag)
        except queue.Empty:
            pass
        root.after(100, poll)
    root.after(100, poll)
    root.mainloop()


if __name__ == "__main__":
    main()